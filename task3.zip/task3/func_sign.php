<?php
include 'connection.php';
$sql = "SELECT SIGN(255.5)";
$result = $conn->query($sql);


echo "<h3>Output for SIGN() Function</h3>";
while($row = $result->fetch_assoc()) {
    echo "Sign of 255.5 = ". $row['SIGN(255.5)'] . "<br>";
}

echo "<br><br>";
echo '<a href="index.php" style="padding: 10px; background-color: #f0f0f0; border: 1px solid #ccc; text-decoration: none; color: black; border-radius: 5px;">Back to Main Menu</a>';
?>