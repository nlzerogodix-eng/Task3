<?php
include 'connection.php';

$sql = "SELECT STR_TO_DATE('August 10 2017', '%M %d %Y')";
$result = $conn->query($sql);

echo "<h3>Function: STR_TO_DATE (Converts String to Date)</h3>";
    echo "  <table border='1'>
                <tr>
                    <th>Result Date</th>
                </tr>";

while($row = $result->fetch_assoc()) {
    echo "  <tr>
                <td>{$row['STR_TO_DATE(\'August 10 2017\', \'%M %d %Y\')']}</td>
            </tr>";
}


echo "</table>";
echo "<br><br>";
echo '<a href="index.php" style="padding: 10px; background-color: #f0f0f0; border: 1px solid #ccc; text-decoration: none; color: black; border-radius: 5px;">Back to Main Menu</a>';
?>