<?php
include 'connection.php';

$sql = "SELECT MICROSECOND('2026-01-20 09:34:00.000023')";
$result = $conn->query($sql);

echo "<h3>Function: MICROSECOND (Returns Microsecond Value from Time)</h3>";
    echo "  <table border='1'>
                <tr>
                    <th>Result Microsecond</th>
                </tr>";

while($row = $result->fetch_assoc()) {
    echo "  <tr>
                <td>{$row['MICROSECOND(\'2026-01-20 09:34:00.000023\')']}</td>
            </tr>";
}


echo "</table>";
echo "<br><br>";
echo '<a href="index.php" style="padding: 10px; background-color: #f0f0f0; border: 1px solid #ccc; text-decoration: none; color: black; border-radius: 5px;">Back to Main Menu</a>';
?>