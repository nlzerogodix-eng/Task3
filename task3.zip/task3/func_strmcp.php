<?php
include 'connection.php';

$sql = "SELECT STRCMP('SQL Tutorial', 'SQL Tutorial') AS ExtractString";
$result = $conn->query($sql);

echo "<h3>Output for STRCMP() Function</h3>";

if ($result) {
    while($row = $result->fetch_assoc()) {
        echo $row['ExtractString'] . "<br>";
    }
} else {
    echo "Error: " . $conn->error;
}

echo "<br><br>";
echo '<a href="index.php" style="padding: 10px; background-color: #f0f0f0; border: 1px solid #ccc; text-decoration: none; color: black; border-radius: 5px;">Back to Main Menu</a>';
?>