<?php
include 'connection.php';

$sql = "SELECT LAST_INSERT_ID()";
$result = $conn->query($sql);


echo "<h3>Output for LAST_INSERT_ID() Function</h3>";
while($row = $result->fetch_assoc()) {
    echo "LAST_INSERT_ID Result = ". $row['LAST_INSERT_ID()'] . "<br>";
}

echo "<br><br>";
echo '<a href="index.php" style="padding: 10px; background-color: #f0f0f0; border: 1px solid #ccc; text-decoration: none; color: black; border-radius: 5px;">Back to Main Menu</a>';
?>