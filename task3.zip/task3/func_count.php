<?php
include 'connection.php';
$sql = "SELECT COUNT(*) AS total FROM usertbl";
$result = $conn->query($sql);
$row = $result->fetch_assoc();

echo "<h3>Output for COUNT() Function</h3>";
echo "Total Users: " . $row['total'];
echo "<br><br>";
echo '<a href="index.php" style="padding: 10px; background-color: #f0f0f0; border: 1px solid #ccc; text-decoration: none; color: black; border-radius: 5px;">Back to Main Menu</a>';
?>