<?php
include 'connection.php';

$sql = "SELECT name, FORMAT(id, 2) AS id_fixed, FORMAT(CHAR_LENGTH(name) * 1000, 0) AS name_score FROM `usertbl`;";

$result = $conn->query($sql);

if (!$result) {
    die("Query Failed: " . $conn->error);
}

echo "<h3> User Data with FORMAT() </h3>";

while($row = $result->fetch_assoc()){
    echo "User: <b>" . $row['name'] . "</b><br>";
    echo "Formatted ID: " . $row['id_fixed'] . "<br>";
    echo "Name Score (with commas): " . $row['name_score'] . "<br><br>";
}

$conn->close();
echo "<br><br>";
echo '<a href="index.php" style="padding: 10px; background-color: #f0f0f0; border: 1px solid #ccc; text-decoration: none; color: black; border-radius: 5px;">Back to Main Menu</a>';
?>