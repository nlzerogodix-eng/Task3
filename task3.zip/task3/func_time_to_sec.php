<?php
include 'connection.php';

$sql = "SELECT TIME_TO_SEC('19:30:10')";
$result = $conn->query($sql);

echo "<h3>Function: TIME_TO_SEC (Converts Time to Seconds)</h3>";
    echo "  <table border='1'>
                <tr>
                    <th>Result Seconds</th>
                </tr>";

while($row = $result->fetch_assoc()) {
    echo "  <tr>
                <td>{$row['TIME_TO_SEC(\'19:30:10\')']}</td>
            </tr>";
}


echo "</table>";
echo "<br><br>";
echo '<a href="index.php" style="padding: 10px; background-color: #f0f0f0; border: 1px solid #ccc; text-decoration: none; color: black; border-radius: 5px;">Back to Main Menu</a>';
?>