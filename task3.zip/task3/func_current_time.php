<?php
include 'connection.php';

$sql = "SELECT CURRENT_TIME()";
$result = $conn->query($sql);

echo "<h3>Function: CURRENT_TIME (Returns Current Time)</h3>";
    echo "  <table border='1'>
                <tr>
                    <th>Result Time</th>
                </tr>";

while($row = $result->fetch_assoc()) {
    echo "  <tr>
                <td>{$row['CURRENT_TIME()']}</td>
            </tr>";
}


echo "</table>";
echo "<br><br>";
echo '<a href="index.php" style="padding: 10px; background-color: #f0f0f0; border: 1px solid #ccc; text-decoration: none; color: black; border-radius: 5px;">Back to Main Menu</a>';
?>