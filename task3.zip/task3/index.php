<?php
include 'connection.php';   
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <title>SQL Function Demonstration</title>
    <style>
        table { width: 100%; border-collapse: collapse; font-family: sans-serif; }
        th, td { border: 1px solid #ddd; padding: 12px; text-align: left; }
        th { background-color: #f4f4f4; }
        code { background: #eee; padding: 2px 5px; }
    </style>
</head>
<body>
    <table>
        <thead>
            <tr>
                <th>SQL Function</th>
                <th>Description</th>
                <th>Example Code</th>
                <th>Example Output</th>
            </tr>
        </thead>
        <tbody>
            <td>String Function</td>
            <tr>
                <td>ASCII()</td>
                <td>function returns the ASCII value for the specific character.</td>
                <td><code>SELECT name, ASCII(UserName) AS NumCodeOfFirstChar FROM usertbl;</code></td>
                <td><a href="func_ascii.php" target="_blank">View Result</a></td>
            </tr>
            
            <tr>
                <td>CHAR_LENGTH()</td>
                <td>Converts a string to upper-case</td>
                <td><code>SELECT CHAR_LENGTH("name") AS LengthOfString FROM usertbl;</code></td>
                <td><a href="func_charlength.php" target="_blank">View Result</a></td>
            </tr>
            <tr>
                <td>CONCAT()</td>
                <td>function adds two or more expressions together.</td>
                <td><code>SELECT CONCAT(name, ' - Email: ', email) AS UserInfo FROM usertbl"</code></td>
                <td><a href="func_upper.php" target="_blank">View Result</a></td>
            </tr>
            <tr>
                <td>CONCATWS()</td>
                <td>Adds two or more expressions together with a separator.</td>
                <td><code>"SELECT id, CONCAT_WS(' | ', name, email, gender, created_at) AS user_summary FROM `usertbl`;"</code></td>
                <td><a href="func_concatws.php" target="_blank">View Result</a></td>
            </tr>
            <tr>
                <td>FIELD()</td>
                <td>The FIELD() function returns the index position of a value in a list of values.</td>
                <td><code>"$sql = "SELECT id, name, gender FROM `usertbl` ORDER BY FIELD(gender, 'Male', 'Female') ASC;";"</code></td>
                <td><a href="func_field.php" target="_blank">View Result</a></td>
            </tr>
          
            <tr>
                <td>FIELD_IN_SET()</td>
                <td>The FIND_IN_SET() function returns the position of a string within a list of strings.</td>
                <td><code>"SELECT id, name, FIND_IN_SET(id, '1,2,3') AS position FROM `usertbl` WHERE FIND_IN_SET(id, '1,2,3') > 0""</code></td>
                <td><a href="func_field_in_set.php" target="_blank">View Result</a></td>
            </tr>
            <tr>
                <td>FORMAT()</td>
                <td>Format the number as "#,###,###.##" (and round with two decimal places).</td>
                <td><code>"SELECT name, FORMAT(id, 2) AS id_fixed, FORMAT(CHAR_LENGTH(name) * 1000, 0) AS name_score FROM `usertbl`"</code></td>
                <td><a href="func_format.php" target="_blank">View Result</a></td>
</tr>
            <tr>
                <td>INSERT()</td>
                <td>The INSERT() function inserts a string within a string at the specified position and for a certain number of characters.</td>
                <td><code>"INSERT INTO `usertbl` (`name`, `password`, `email`, `gender`)VALUES ('John Doe', '12345', 'john@example.com', 'Male');"</code></td>
                <td><a href="func_insert.php" target="_blank">View Result</a></td>
            </tr>
            <tr>
                <td>INSTR()</td>
                <td>The INSTR() function returns the position of the first occurrence of a string in another string.</td>
                <td><code>"SELECT INSTR(name) AS MatchPosition FROM usertbl"</code></td>
                <td><a href="func_instr.php" target="_blank">View Result</a></td>
            </tr>
            <tr>
                <td>LCASE()</td>
                <td>The LCASE() function converts a string to lower-case.</td>
                <td><code>"SELECT LCASE(name) AS LCASE FROM usertbl"</code></td>
                <td><a href="func_lcase.php" target="_blank">View Result</a></td>
            </tr>
            <tr>
                <td>LEFT()</td>
                <td>The LEFT() function extracts a number of characters from a string (starting from left).</td>
                <td><code>"SELECT LEFT("SQL Tutorial", 3) AS ExtractString;"</code></td>
                <td><a href="func_left.php" target="_blank">View Result</a></td>
            </tr>
            <tr>
                <td>LENGTH()</td>
                <td>The LENGTH() function returns the length of a string (in bytes).</td>
                <td><code>"SELECT LENGTH("SQL Tutorial") AS LengthOfString;"</code></td>
                <td><a href="func_length.php" target="_blank">View Result</a></td>
            </tr>
            <tr>
                <td>LOCATE()</td>
                <td>The LOCATE() function returns the position of the first occurrence of a substring in a string.</td>
                <td><code>"SELECT LOCATE("3", "W3Schools.com") AS MatchPosition;"</code></td>
                <td><a href="func_locate.php" target="_blank">View Result</a></td>
            </tr>
            <tr>
                <td>LOWER()</td>
                <td>The LOWER() function converts a string to lower-case.</td>
                <td><code>"SELECT LOWER("SQL Tutorial is FUN!");"</code></td>
                <td><a href="func_lower.php" target="_blank">View Result</a></td>
            </tr>
            <tr>
                <td>LPAD()</td>
                <td>The LPAD() function left-pads a string with another string, to a certain length.</td>
                <td><code>SELECT LPAD("SQL Tutorial", 20, "ABC");</code></td>
                <td><a href="func_lpad.php" target="_blank">View Result</a></td>
            </tr>
            <tr>
                <td>LTRIM()</td>
                <td>The LTRIM() function removes leading spaces from a string.</td>
                <td><code>"SELECT LTRIM("     SQL Tutorial") AS LeftTrimmedString;"</code></td>
                <td><a href="func_ltrim.php" target="_blank">View Result</a></td>
            </tr>
           
            <tr>
                <td>MID()</td>
                <td>The MID() function extracts a substring from a string (starting at any position).</td>
                <td><code>"SELECT MID("SQL Tutorial", 5, 3) AS ExtractString;"</code></td>
                <td><a href="func_mid.php" target="_blank">View Result</a></td>
            </tr>
            
            <tr>
                <td>POSITION()</td>
                <td>The POSITION() function returns the position of the first occurrence of a substring in a string.</td>
                <td><code>"SELECT POSITION("3" IN "W3Schools.com") AS MatchPosition;"</code></td>
                <td><a href="func_position.php" target="_blank">View Result</a></td>
            </tr>
            
            <tr>
                <td>REPEAT()</td>
                <td>The REPEAT() function repeats a string as many times as specified.</td>
                <td><code>"SELECT REPEAT("SQL Tutorial", 3);"</code></td>
                <td><a href="func_repeat.php" target="_blank">View Result</a></td>
            </tr>
            <tr>
                <td>REPLACE() </td>
                <td>The REPLACE() function replaces all occurrences of a substring within a string, with a new substring.</td>
                <td><code>"SELECT REPLACE("SQL Tutorial", "SQL", "HTML");"</code></td>
                <td><a href="func_replace.php" target="_blank">View Result</a></td>
            </tr>
            <tr>
                <td>REVERSE()</td>
                <td>The REVERSE() function reverses a string and returns the result.</td>
                <td><code>"SELECT REVERSE("SQL Tutorial");"</code></td>
                <td><a href="func_replace.php" target="_blank">View Result</a></td>
            </tr>
            <tr>
                <td> RIGHT() </td>
                <td>The RIGHT() function extracts a number of characters from a string (starting from right).</td>
                <td><code>"SELECT RIGHT("SQL Tutorial is cool", 4) AS ExtractString;"</code></td>
                <td><a href="func_right.php" target="_blank">View Result</a></td>
            </tr>
            <tr>
                <td> RPAD() </td>
                <td>The RPAD() function right-pads a string with another string, to a certain length.</td>
                <td><code>"SELECT RPAD("SQL Tutorial", 20, "ABC");"</code></td>
                <td><a href="func_rpad.php" target="_blank">View Result</a></td>
            </tr>
            <tr>
                <td>RTRIM()</td>
                <td>The RTRIM() function removes trailing spaces from a string.</td>
                <td><code>"SELECT RTRIM("SQL Tutorial     ") AS RightTrimmedString;"</code></td>
                <td><a href="func_rtrim.php" target="_blank">View Result</a></td>
            </tr>
            <tr>
                <td>SPACE()</td>
                <td>The SPACE() function returns a string of the specified number of space characters.</td>
                <td><code>"SELECT SPACE(10);"</code></td>
                <td><a href="func_space.php" target="_blank">View Result</a></td>
            </tr>
            <tr>
                <td>SUBSTR() </td>
                <td>The SUBSTR() function extracts a substring from a string (starting at any position).</td>
                <td><code>"SELECT SUBSTR("SQL Tutorial", 5, 3) AS ExtractString;"</code></td>
                <td><a href="func_substr.php" target="_blank">View Result</a></td>
            </tr>
            <tr>
                <td>SUBSTRING() </td>
                <td>The SUBSTRING() function extracts a substring from a string (starting at any position).</td>
                <td><code>"SELECT SUBSTRING("SQL Tutorial", 5, 3) AS ExtractString;"</code></td>
                <td><a href="func_substring.php" target="_blank">View Result</a></td>
            </tr>
            <tr>
                <td>STRMCP() </td>
                <td>The STRCMP() function compares two strings.</td>
                <td><code>"SELECT STRCMP("SQL Tutorial", "SQL Tutorial");"</code></td>
                <td><a href="func_strmcp.php" target="_blank">View Result</a></td>
            </tr>
            <tr>
                <td>SUBSTRING_INDEX()</td>
                <td>The SUBSTRING_INDEX() function returns a substring of a string before a specified number of delimiter occurs.</td>
                <td><code>"SELECT SUBSTRING_INDEX("www.w3schools.com", ".", 1);"</code></td>
                <td><a href="func_substring_index.php" target="_blank">View Result</a></td>
            </tr>
            <tr>
                <td>TRIM() </td>
                <td>The TRIM() function removes leading and trailing spaces from a string.</td>
                <td><code>"SELECT TRIM('    SQL Tutorial    ') AS TrimmedString;"</code></td>
                <td><a href="func_trim.php" target="_blank">View Result</a></td>
            </tr>
            <tr>
                <td>UCASE()</td>
                <td>The UCASE() function converts a string to upper-case.</td>
                <td><code>"SELECT UCASE("SQL Tutorial is FUN!");"</code></td>
                <td><a href="func_ucase.php" target="_blank">View Result</a></td>
            </tr>
            <tr>
                <td>UPPER()</td>
                <td>Converts a string to upper-case</td>
                <td><code>SELECT UPPER(name) FROM usertbl;</code></td>
                <td><a href="func_upper.php" target="_blank">View Result</a></td>
            </tr> <tr>
                <td></td>
                <td></td>
                <td><code></code></td>
              
            </tr>
            <td>Numeric Function</td>
            <tr>
                <td></td>
                <td></td>
                <td><code></code></td>
              
            </tr>
            <tr>
                <td>ABS()</td>
                <td>The ABS() function returns the absolute (positive) value of a number.</td>
                <td><code>"SELECT ABS(-350)";</code></td>
                <td><a href="func_abs.php" target="_blank">View Result</a></td>
            </tr>
            <tr>
                <td>ACOS()</td>
                <td>The ACOS() function returns the arc cosine of a number.</td>
                <td><code>"SELECT ABS(-350)";</code></td>
                <td><a href="func_acos.php" target="_blank">View Result</a></td>
            </tr>
            <tr>
                <td>ATAN()</td>
                <td>The ATAN() function returns the arc tangent of one or two numbers.</td>
                <td><code>"SELECT ATAN(2.5);";</code></td>
                <td><a href="func_atan.php" target="_blank">View Result</a></td>
            </tr>
            <tr>
                <td>ATAN2()</td>
                <td>The ATAN2() function returns the arc tangent of two numbers.</td>
                <td><code>"SELECT ATAN2(0.50, 1)";</code></td>
                <td><a href="func_atan2.php" target="_blank">View Result</a></td>
            </tr>
            <tr>
                <td> AVG()</td>
                <td>The AVG() function returns the average value of an expression.</td>
                <td><code>"SELECT AVG(points) AS AveragePoint FROM user_points";</code></td>
                <td><a href="func_avg.php" target="_blank">View Result</a></td>
            </tr>
            <tr>
                <td>CEIL()</td>
                <td>The CEIL() function returns the smallest integer value that is bigger than or equal to a number..</td>
                <td><code>"SELECT CEIL(25.75)";</code></td>
                <td><a href="func_ceil.php" target="_blank">View Result</a></td>
            </tr>
            <tr>
                <td>CEILING()</td>
                <td>The CEILING() function returns the smallest integer value that is bigger than or equal to a number.</td>
                <td><code>"SELECT CEILING(25.75)";</code></td>
                <td><a href="func_ceiling.php" target="_blank">View Result</a></td>
            </tr>
            <tr>
                <td>COS()</td>
                <td>The COS() function returns the cosine of a number.</td>
                <td><code>"SELECT COS(2)";</code></td>
                <td><a href="func_cos.php" target="_blank">View Result</a></td>
            </tr>
            <tr>
                <td>COT()</td>
                <td>The COT() function returns the cotangent of a number.</td>
                <td><code>"SELECT COT(6)";</code></td>
                <td><a href="func_cot.php" target="_blank">View Result</a></td>
            </tr> 
            <tr>
                <td>COUNT()</td>
                <td>Returns the number of rows</td>
                <td><code>SELECT COUNT(*) AS total FROM usertbl;</code></td>
                <td><a href="func_count.php" target="_blank">View Result</a></td>
            </tr>
           
            <tr>
                <td>DEGREES()</td>
                <td>The DEGREES() function converts a value in radians to degrees.</td>
                <td><code>"SELECT DEGREES(1.5)";</code></td>
                <td><a href="func_degrees.php" target="_blank">View Result</a></td>
            </tr>
            <tr>
                <td>DIV()</td>
                <td>The DIV function is used for integer division (x is divided by y). An integer value is returned.</td>
                <td><code>"SELECT 10 DIV 5";</code></td>
                <td><a href="func_div.php" target="_blank">View Result</a></td>
            </tr>
            <tr>
                <td>ASIN()</td>
                <td>The EXP() function returns e raised to the power of the specified number.</td>
                <td><code>"SELECT ASIN(0.25);";</code></td>
                <td><a href="func_asin.php" target="_blank">View Result</a></td>
            </tr>
            <tr>
                <td>FLOOR()</td>
                <td>The FLOOR() function returns the largest integer value that is smaller than or equal to a number.</td>
                <td><code>"SELECT FLOOR(25.75)";</code></td>
                <td><a href="func_floor.php" target="_blank">View Result</a></td>
            </tr>
            <tr>
                <td>GREATEST()</td>
                <td>The GREATEST() function returns the greatest value of the list of arguments.</td>
                <td><code>"SELECT GREATEST(3, 12, 34, 8, 25)";</code></td>
                <td><a href="func_greatest.php" target="_blank">View Result</a></td>
            </tr>
            <tr>
                <td>LEAST()</td>
                <td>The LEAST() function returns the smallest value of the list of arguments.</td>
                <td><code>"SELECT LEAST(3, 12, 34, 8, 25)";</code></td>
                <td><a href="func_least.php" target="_blank">View Result</a></td>
            </tr>
            <tr>
                <td>LN()</td>
                <td>The LN() function returns the natural logarithm of a number.</td>
                <td><code>"SELECT LN(2)";</code></td>
                <td><a href="func_ln.php" target="_blank">View Result</a></td>
            </tr>
            <tr>
                <td>LOG2()</td>
                <td>The LOG2() function returns the natural logarithm of a specified number, or the logarithm of the number to the specified base.</td>
                <td><code>"SELECT LOG2(6)";</code></td>
                <td><a href="func_log2.php" target="_blank">View Result</a></td>
            </tr>
            <tr>
                <td>LOG10()</td>
                <td>The LOG10() function returns the natural logarithm of a number to base-10.</td>
                <td><code>"SELECT ABS(-350)";</code></td>
                <td><a href="func_log10.php" target="_blank">View Result</a></td>
            </tr>
              <tr>
                <td>MIN()</td>
                <td>The MIN() function returns the minimum value in a set of values.</td>
                <td><code>"SELECT MIN(points) AS SmallestPoint FROM user_points";</code></td>
                <td><a href="func_min.php" target="_blank">View Result</a></td>
            </tr>
            <tr>
                <td> MOD()</td>
                <td>The MOD() function returns the remainder of a number divided by another number.</td>
                <td><code>"SELECT MOD(18, 4)";</code></td>
                <td><a href="func_mod.php" target="_blank">View Result</a></td>
            </tr>
            <tr>
                <td>POW()</td>
                <td>The POW() function returns the value of a number raised to the power of another number.</td>
                <td><code>"SELECT POW(4, 2)";</code></td>
                <td><a href="func_pow.php" target="_blank">View Result</a></td>
            </tr>
            <tr>
                <td>RADIANS()</td>
                <td>The RADIANS() function converts a degree value into radians.</td>
                <td><code>"SELECT RADIANS(180)";</code></td>
                <td><a href="func_radians.php" target="_blank">View Result</a></td>
            </tr>
            <tr>
                <td>RAND()</td>
                <td>The RAND() function returns a random number between 0 (inclusive) and 1 (exclusive).</td>
                <td><code>"SELECT RAND()";</code></td>
                <td><a href="func_rand.php" target="_blank">View Result</a></td>
            </tr>
            <tr>
                <td>ROUND()</td>
                <td>The ROUND() function rounds a number to a specified number of decimal places..</td>
                <td><code>"SELECT ROUND(135.375, 2)";</code></td>
                <td><a href="func_round.php" target="_blank">View Result</a></td>
            </tr>
            <tr>
                <td>SIGN()</td>
                <td>The SIGN() function returns the sign of a number.</td>
                <td><code>"SELECT SIGN(255.5)";</code></td>
                <td><a href="func_sign.php" target="_blank">View Result</a></td>
            </tr>
            <tr>
                <td>SIN()</td>
                <td>The SIN() function returns the sine of a number.</td>
                <td><code>"SELECT SIN(2)";</code></td>
                <td><a href="func_sin.php" target="_blank">View Result</a></td>
            </tr>
            <tr>
                <td>SQRT()</td>
                <td>The SQRT() function returns the square root of a number.</td>
                <td><code>"SELECT SQRT(64)";</code></td>
                <td><a href="func_sqrt.php" target="_blank">View Result</a></td>
            </tr>
            <tr>
                <td>SUM()</td>
                <td>Calculates the sum of a numeric column</td>
                <td><code>SELECT SUM(points) AS TotalPoints FROM user_points;</code></td>
                <td><a href="func_sum.php" target="_blank">View Result</a></td>
            </tr>
                <tr>
                <td>TAN()</td>
                <td>SELECT TAN(1.75).</td>
                <td><code>SELECT SUM(points) FROM user_points;</code></td>
                <td><a href="func_tan.php" target="_blank">View Result</a></td>
            </tr>
            <tr>
                <td>TRUNCATE()</td>
                <td>The TRUNCATE() function truncates a number to the specified number of decimal places.</td>
                <td><code>SELECT TRUNCATE(135.375, 2);</code></td>
                <td><a href="func_truncate.php" target="_blank">View Result</a></td>
            </tr> <tr>
                <td></td>
                <td></td>
                <td><code></code></td>
              
            </tr>
    <td>Date Function</td>
     <tr>
                <td></td>
                <td></td>
                <td><code></code></td>
              
            </tr>        
    <tr>
                <td>ADD_DATE()</td>
                <td>The ADDDATE() function adds a time/date interval to a date and then returns the date.</td>
                <td><code>SELECT ADDDATE('2025-01-15', INTERVAL -2 MONTH)</code></td>
                <td><a href="func_adddate.php" target="_blank">View Result</a></td>
            </tr>
            <tr>
                <td>ADD_TIME()</td>
                <td>The ADDTIME() function adds a time interval to a time/datetime and then returns the time/datetime.</td>
                <td><code>SELECT ADDTIME('2017-06-15 09:34:21', '2')</code></td>
                <td><a href="func_addtime.php" target="_blank">View Result</a></td>
            </tr>
            <tr>
                <td>CURDATE()</td>
                <td>The CURDATE() function returns the current date.</td>
                <td><code>SELECT CURDATE()</code></td>
                <td><a href="func_curdate.php" target="_blank">View Result</a></td>
            </tr>
            <tr>
                <td>CURRENT_DATE()</td>
                <td>The CURRENT_DATE() function returns the current date.</td>
                <td><code>SELECT CURRENT_DATE()</code></td>
                <td><a href="func_current_date.php" target="_blank">View Result</a></td>
            </tr>
            <tr>
                <td> CURRENT_TIME() </td>
                <td>The CURRENT_TIME() function returns the current time.</td>
                <td><code>SELECT CURRENT_TIME()</code></td>
                <td><a href="func_current_time.php" target="_blank">View Result</a></td>
            </tr>
            <tr>
                <td>CURRENT_TIMESTAMP()</td>
                <td>The CURRENT_TIMESTAMP() function returns the current date and time.</td>
                <td><code>SELECT CURRENT_TIMESTAMP()</code></td>
                <td><a href="func_current_timestamp.php" target="_blank">View Result</a></td>
            </tr>
            <tr>
                <td>CURTIME()</td>
                <td>The CURTIME() function returns the current time.</td>
                <td><code>SELECT CURTIME()</code></td>
                <td><a href="func_curtime.php" target="_blank">View Result</a></td>
            </tr>
            <tr>
                <td>DATE()</td>
                <td>The DATE() function extracts the date part from a datetime expression.</td>
                <td><code>SELECT DATE('2025-08-20') FROM usertbl"</code></td>
                <td><a href="func_date.php" target="_blank">View Result</a></td>
            </tr>
            <tr>
                <td>DATEDIFF()</td>
                <td>The DATEDIFF() function returns the number of days between two date values.</td>
                <td><code>"SELECT DATEDIFF('2025-01-15', '2026-01-05')"</code></td>
                <td><a href="func_datediff.php" target="_blank">View Result</a></td>
            </tr>
            <tr>
                <td>DATE_ADD() </td>
                <td>The DATE_ADD() function adds a time/date interval to a date and then returns the date.</td>
                <td><code>SELECT DATE_ADD('2025-01-15', INTERVAL 10 DAY)</code></td>
                <td><a href="func_date_add.php" target="_blank">View Result</a></td>
            </tr>
            <tr>
                <td>DATE_FORMAT()</td>
                <td>function formats a date as specified.</td>
                <td><code>SELECT DATE_FORMAT('2025-01-15', '%M %d %Y')</code></td>
                <td><a href="func_dateformat.php" target="_blank">View Result</a></td>
            </tr>
            <tr>
                <td>DATE_SUB()</td>
                <td>The DATE_SUB() function subtracts a time/date interval from a date and then returns the date.</td>
                <td><code>SELECT DATE_SUB('2026-01-05', INTERVAL 10 DAY)</code></td>
                <td><a href="func_date_sub.php" target="_blank">View Result</a></td>
            </tr>

            <tr>
                <td>DAY()</td>
                <td>The DAY() function returns the day of the month for a given date (a number from 1 to 31).</td>
                <td><code>SELECT DAY('2025-01-15')</code></td>
                <td><a href="func_day.php" target="_blank">View Result</a></td>
            </tr>
     
            <tr>
                <td>DAYNAME()</td>
                <td>The DAYNAME() function returns the weekday name for a given date.</td>
                <td><code>SELECT DAYNAME('2025-01-15')</code></td>
                <td><a href="func_dayname.php" target="_blank">View Result</a></td>
            </tr>
     
            <tr>
                <td>DAYOFMONTH()</td>
                <td>The DAYOFMONTH() function returns the day of the month for a given date (a number from 1 to 31).</td>
                <td><code>SELECT DAYOFMONTH('2025-01-15')</code></td>
                <td><a href="func_dayofmonth.php" target="_blank">View Result</a></td>
            </tr>
    
            <tr>
                <td>DAYOFWEEK()</td>
                <td>The DAYOFWEEK() function returns the weekday index for a given date (a number from 1 to 7).</td>
                <td><code>SELECT DAYOFWEEK('2025-01-15')</code></td>
                <td><a href="func_dayofweek.php" target="_blank">View Result</a></td>
            </tr>
      
            <tr>
                <td>DAYOFYEAR()</td>
                <td>The DAYOFYEAR() function returns the day of the year for a given date (a number from 1 to 366).</td>
                <td><code>SELECT DAYOFYEAR('2025-01-15')</code></td>
                <td><a href="func_dayofyear.php" target="_blank">View Result</a></td>
            </tr>
       
            <tr>
                <td>EXTRACT()</td>
                <td>The EXTRACT() function extracts a part from a given date.</td>
                <td><code>SELECT EXTRACT(MONTH FROM '2025-01-15')</code></td>
                <td><a href="func_extract.php" target="_blank">View Result</a></td>
            </tr>
      
            <tr>
                <td>FROM_DAYS()</td>
                <td>The FROM_DAYS() function returns a date from a numeric datevalue.</td>
                <td><code>SELECT FROM_DAYS(685467)</code></td>
                <td><a href="func_from_days.php" target="_blank">View Result</a></td>
            </tr>
      
            <tr>
                <td>HOUR()</td>
                <td>The HOUR() function returns the hour part for a given date (from 0 to 838).</td>
                <td><code>SELECT HOUR('2026-01-05 09:15:00')</code></td>
                <td><a href="func_hour.php" target="_blank">View Result</a></td>
            </tr>
      
            <tr>
                <td>LAST_DAY()</td>
                <td>The LAST_DAY() function extracts the last day of the month for a given date</td>
                <td><code>SELECT LAST_DAY('2026-01-05 09:15:00')</code></td>
                <td><a href="func_last_day.php" target="_blank">View Result</a></td>
            </tr>
      
            <tr>
                <td>LOCALTIME()</td>
                <td>The LOCALTIME() function returns the current date and time.</td>
                <td><code>SELECT LOCALTIME()</code></td>
                <td><a href="func_localtime.php" target="_blank">View Result</a></td>
            </tr>
      
            <tr>
                <td>LOCALTIMESTAMP()</td>
                <td>The LOCALTIMESTAMP() function returns the current date and time.</td>
                <td><code>SELECT LOCALTIMESTAMP()</code></td>
                <td><a href="func_localtimestamp.php" target="_blank">View Result</a></td>
            </tr>
            <tr>
                <td>MAKEDATE()</td>
                <td>The MAKEDATE() function creates and returns a date based on a year and a number of days value.</td>
                <td><code>SELECT MAKEDATE(2026, 15)</code></td>
                <td><a href="func_makedate.php" target="_blank">View Result</a></td>
            </tr>
            <tr>
                <td>MAKETIME()</td>
                <td>The MAKETIME() function creates and returns a time based on an hour, minute, and second value.</td>
                <td><code>SELECT MAKETIME(11, 35, 4)</code></td>
                <td><a href="func_maketime.php" target="_blank">View Result</a></td>
            </tr>
            <tr>
                <td>MICROSECOND() </td>
                <td>The MICROSECOND() function returns the microsecond part of a time/datetime (from 0 to 999999).</td>
                <td><code>SELECT MICROSECOND('2026-01-20 09:34:00.000023')</code></td>
                <td><a href="func_microsecond.php" target="_blank">View Result</a></td>
            </tr>
            <tr>
                <td>MINUTE()</td>
                <td>The MINUTE() function returns the minute part of a time/datetime (from 0 to 59)</td>
                <td><code>SELECT MINUTE('2025-06-20 09:34:00')</code></td>
                <td><a href="func_localtimestamp.php" target="_blank">View Result</a></td>
            </tr>
           <tr>
                <td>MONTH()</td>
                <td>The MONTH() function returns the month part for a given date (a number from 1 to 12).</td>
                <td><code>SELECT MONTH('2026-02-15')</code></td>
                <td><a href="func_month.php" target="_blank">View Result</a></td>
            </tr>
           <tr>
                <td>MONTHNAME()</td>
                <td>The MONTHNAME() function returns the name of the month for a given date.</td>
                <td><code>SELECT MONTHNAME('2025-06-15');</code></td>
                <td><a href="func_monthname.php" target="_blank">View Result</a></td>
            </tr>
           <tr>
                <td>NOW()</td>
                <td>The NOW() function returns the current date and time.</td>
                <td><code>SELECT NOW()</code></td>
                <td><a href="func_now.php" target="_blank">View Result</a></td>
            </tr>
           <tr>
                <td>PERIOD_ADD()</td>
                <td>The PERIOD_ADD() function adds a specified number of months to a period.</td>
                <td><code>SELECT PERIOD_ADD(202503, 5)</code></td>
                <td><a href="func_period_add.php" target="_blank">View Result</a></td>
            </tr>
           <tr>
                <td> PERIOD_DIFF()</td>
                <td>The PERIOD_DIFF() function returns the difference between two periods. The result will be in months.</td>
                <td><code>SELECT PERIOD_DIFF(202310, 202603)</code></td>
                <td><a href="func_period_diff.php" target="_blank">View Result</a></td>
            </tr>
           <tr>
                <td> QUARTER()</td>
                <td>The QUARTER() function returns the quarter of the year for a given date value (a number from 1 to 4).</td>
                <td><code>SELECT QUARTER('2023-06-15')</code></td>
                <td><a href="func_quarter.php" target="_blank">View Result</a></td>
            </tr>
           <tr>
                <td>SEC_TO_TIME()</td>
                <td>The SEC_TO_TIME() function returns a time value (in format HH:MM:SS) based on the specified seconds.</td>
                <td><code>SELECT SEC_TO_TIME(500)</code></td>
                <td><a href="func_sec_to_time.php" target="_blank">View Result</a></td>
            </tr>
           <tr>
                <td>STR_TO_DATE()</td>
                <td>The STR_TO_DATE() function returns a date based on a string and a format.</td>
                <td><code>SELECT STR_TO_DATE('August 10 2017', '%M %d %Y')</code></td>
                <td><a href="func_str_to_date.php" target="_blank">View Result</a></td>
            </tr>
           <tr>
                <td>SUBDATE()</td>
                <td>The SUBDATE() function subtracts a time/date interval from a date and then returns the date.</td>
                <td><code>SELECT SUBDATE('2024-06-15', INTERVAL 10 DAY)</code></td>
                <td><a href="func_subdate.php" target="_blank">View Result</a></td>
            </tr>
           <tr>
                <td>SUBTIME() </td>
                <td>The SUBTIME() function subtracts time from a time/datetime expression and then returns the new time/datetime.</td>
                <td><code>"SELECT SUBTIME('2022-06-15 10:24:21.000004', '5.000001')</code></td>
                <td><a href="func_subtime.php" target="_blank">View Result</a></td>
            </tr>
           <tr>
                <td>SYSDATE()</td>
                <td>The SYSDATE() function returns the current date and time.</td>
                <td><code>SELECT SYSDATE()</code></td>
                <td><a href="func_sysdate.php" target="_blank">View Result</a></td>
            </tr>
     
           <tr>
                <td>TIME()</td>
                <td>The TIME() function returns the current date and time.</td>
                <td><code>"SELECT TIME('2022-08-15 19:30:10.000001')</code></td>
                <td><a href="func_time.php" target="_blank">View Result</a></td>
            </tr>
          
           <tr>
                <td>TIME_FORMAT()</td>
                <td>The TIME_FORMAT() function formats a time by a specified format.</td>
                <td><code>SELECT TIME_FORMAT('19:30:10', '%H %i %s')</code></td>
                <td><a href="func_time_format.php" target="_blank">View Result</a></td>
            </tr>
           
           <tr>
                <td> TIME_TO_SEC() </td>
                <td>The TIME_TO_SEC() function converts a time value into seconds.</td>
                <td><code>SELECT TIME_TO_SEC('19:30:10')</code></td>
                <td><a href="func_time_to_sec.php" target="_blank">View Result</a></td>
            </tr>
      
           <tr>
                <td>TIMEDIFF()</td>
                <td>The TIMEDIFF() function returns the difference between two time/datetime expressions.</td>
                <td><code>SELECT TIMEDIFF('13:10:11', '13:10:10')</code></td>
                <td><a href="func_timediff.php" target="_blank">View Result</a></td>
            </tr>

           <tr>
                <td>TIMESTAMP()</td>
                <td>The TIMESTAMP() function returns a datetime value based on a date or datetime value.</td>
                <td><code>SELECT TIMESTAMP('2021-07-23',  '13:10:11')</code></td>
                <td><a href="func_timestamp.php" target="_blank">View Result</a></td>
            </tr>
           <tr>
                <td>TO_DAYS()</td>
                <td>The TO_DAYS() function returns the number of days between a date and year 0 (date "0000-00-00").</td>
                <td><code>SELECT TO_DAYS('2020-06-20')</code></td>
                <td><a href="func_to_days.php" target="_blank">View Result</a></td>
            </tr>
           <tr>
                <td>WEEK() </td>
                <td>The WEEK() function returns the week number for a given date (a number from 0 to 53).</td>
                <td><code>SELECT WEEK('2010-06-15')</code></td>
                <td><a href="func_week.php" target="_blank">View Result</a></td>
            </tr>
           <tr>
                <td>WEEKDAY()</td>
                <td>The WEEKDAY() function returns the weekday number for a given date.</td>
                <td><code>SELECT WEEKDAY('2026-06-15')</code></td>
                <td><a href="func_weekday.php" target="_blank">View Result</a></td>
            </tr>
           <tr>
                <td>WEEKOFYEAR()</td>
                <td>The WEEKOFYEAR() function returns the week number for a given date (a number from 1 to 53).</td>
                <td><code>SELECT WEEKOFYEAR('2025-06-15')</code></td>
                <td><a href="func_weekofyear.php" target="_blank">View Result</a></td>
            </tr>
           <tr>
                <td>YEAR()</td>
                <td>The YEAR() function returns the year part for a given date (a number from 1000 to 9999).</td>
                <td><code>SELECT YEAR('2024-06-15')</code></td>
                <td><a href="func_year.php" target="_blank">View Result</a></td>
            </tr>
           <tr>
                <td>YEARWEEK()</td>
                <td>SELECT YEARWEEK('2023-06-15')</td>
                <td><code>SELECT name, DATE_FORMAT(created_at, '%M %e, %Y') AS joined_date FROM usertbl</code></td>
                <td><a href="func_yearweek.php" target="_blank">View Result</a></td>
            </tr>
           <tr>
             <tr>
                <td></td>
                <td></td>
                <td><code></code></td>
              
            </tr>
            <td>ADVANCED FUNCTIONS</td>
           </tr>
            <tr>
                <td></td>
                <td></td>
                <td><code></code></td>
              
            </tr>
           <tr>
                <td>BIN()</td>
                <td>The BIN() function returns a binary representation of a number, as a string value.</td>
                <td><code>SELECT BIN(15);</code></td>
                <td><a href="func_bin.php" target="_blank">View Result</a></td>
            </tr><tr>
                <td>BINARY()</td>
                <td>The BINARY function converts a value to a binary string.</td>
                <td><code>SELECT BINARY "W3Schools.com";</code></td>
                <td><a href="func_binary.php" target="_blank">View Result</a></td>
            </tr><tr>
                <td>CASE()</td>
                <td>The CASE statement goes through conditions and return a value when the first condition is met (like an IF-THEN-ELSE statement). </td>
                <td><code>SELECT OrderID, Quantity,
CASE
    WHEN Quantity > 30 THEN "The quantity is greater than 30"
    WHEN Quantity = 30 THEN "The quantity is 30"
    ELSE "The quantity is under 30"
END
FROM OrderDetails;</code></td>
                <td><a href="func_case.php" target="_blank">View Result</a></td>
            </tr>  
            <tr>
                <td>CAST()</td>
                <td>The CAST() function converts a value (of any type) into the specified datatype.</td>
                <td><code>SELECT CAST("2017-08-29" AS DATE);</code></td>
                <td><a href="func_cast.php" target="_blank">View Result</a></td>
            </tr>
            <tr>
                <td>COALESCE()</td>
                <td>The COALESCE() function returns the first non-null value in a list.;</td>
                <td><code>SELECT COALESCE(NULL, NULL, NULL, 'W3Schools.com', NULL, 'Example.com');</code></td>
                <td><a href="func_coalesce.php" target="_blank">View Result</a></td>
            </tr>
            <tr>
                <td>CONNECTION_ID()</td>
                <td>The CONNECTION_ID() function returns the unique connection ID for the current connection.</td>
                <td><code>The CONNECTION_ID() function returns the unique connection ID for the current connection.</code></td>
                <td><a href="func_connection_id.php" target="_blank">View Result</a></td>
            </tr>
            <tr>
                <td>CONV()</td>
                <td>The CONV() function converts a number from one numeric base system to another, and returns the result as a string value.</td>
                <td><code>SELECT CONV(15, 10, 2);</code></td>
                <td><a href="func_conv.php" target="_blank">View Result</a></td>
            </tr>
            <tr>
                <td> CONVERT()</td>
                <td>The CONVERT() function converts a value into the specified datatype or character set.</td>
                <td><code>SELECT CONVERT("2017-08-29", DATE);</code></td>
                <td><a href="func_convert.php" target="_blank">View Result</a></td>
            </tr>
            <tr>
                <td>CURRENT_USER()</td>
                <td>The CURRENT_USER() function returns the user name and host name for the MySQL account that the server used to authenticate the current client.</td>
                <td><code>SELECT CURRENT_USER();</code></td>
                <td><a href="func_current_user.php" target="_blank">View Result</a></td>
            </tr>
            <tr>
                <td>DATABASE()</td>
                <td>The DATABASE() function returns the name of the current database.</td>
                <td><code>SELECT DATABASE();</code></td>
                <td><a href="func_database.php" target="_blank">View Result</a></td>
            </tr>
            <tr>
                <td>IF() </td>
                <td>The IF() function returns a value if a condition is TRUE, or another value if a condition is FALSE.</td>
                <td><code>SELECT IF(500< 1000, "YES", "NO");</code></td>
                <td><a href="func_if.php" target="_blank">View Result</a></td>
            </tr>
            <tr>
                <td>IFNULL()</td>
                <td>The IFNULL() function returns a specified value if the expression is NULL./td>
                <td><code>SELECT IFNULL(NULL, "W3Schools.com");</code></td>
                <td><a href="func_ifnull.php" target="_blank">View Result</a></td>
            </tr>
            <tr>
                <td>ISNULL()</td>
                <td>The ISNULL() function returns 1 or 0 depending on whether an expression is NULL.</td>
                <td><code>SELECT ISNULL(NULL);</code></td>
                <td><a href="func_isnull.php" target="_blank">View Result</a></td>
            </tr>
            <tr>
                <td>LAST_INSERT_ID()</td>
                <td>The LAST_INSERT_ID() function returns the AUTO_INCREMENT id of the last row that has been inserted or updated in a table.</td>
                <td><code>SELECT LAST_INSERT_ID();</code></td>
                <td><a href="func_last_insert_id.php" target="_blank">View Result</a></td>
            </tr>
            <tr>
                <td>NULLIF</td>
                <td>The NULLIF() function compares two expressions and returns NULL if they are equal. Otherwise, the first expression is returned.</td>
                <td><code>SELECT NULLIF(25, 25);</code></td>
                <td><a href="func_nullif.php" target="_blank">View Result</a></td>
            </tr>
            <tr>
                <td>SESSION_USER()</td>
                <td>The SESSION_USER() function returns the current user name and host name for the MySQL connection.</td>
                <td><code>SELECT SESSION_USER();</code></td>
                <td><a href="func_session_user.php" target="_blank">View Result</a></td>
            </tr>
            <tr>
                <td>SYSTEM_USER()</td>
                <td>The SYSTEM_USER() function returns the current user name and host name for the MySQL connection.</td>
                <td><code>SELECT SYSTEM_USER();</code></td>
                <td><a href="func_system_user.php" target="_blank">View Result</a></td>
            </tr>
            <tr>
                <td> USER()</td>
                <td>The USER() function returns the current user name and host name for the MySQL connection.</td>
                <td><code>SELECT USER();</code></td>
                <td><a href="func_user.php" target="_blank">View Result</a></td>
            </tr>
            <tr>
                <td>VERSION()</td>
                <td>The VERSION() function returns the current version of the MySQL database, as a string.</td>
                <td><code>SELECT VERSION();</code></td>
                <td><a href="func_version.php" target="_blank">View Result</a></td>
            </tr>
           
            

       </tbody>
    </table>
</body>
</html> 