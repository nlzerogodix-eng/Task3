<?php
include 'connection.php';

$sql = "SELECT TIME_FORMAT('19:30:10', '%H %i %s')";
$result = $conn->query($sql);

echo "<h3>Function: TIME_FORMAT (Formats Time Value)</h3>";
    echo "  <table border='1'>
                <tr>
                    <th>Result Time</th>
                </tr>";

while($row = $result->fetch_assoc()) {
    echo "  <tr>
                <td>{$row['TIME_FORMAT(\'19:30:10\', \'%H %i %s\')']}</td>
            </tr>";
}


echo "</table>";
echo "<br><br>";
echo '<a href="index.php" style="padding: 10px; background-color: #f0f0f0; border: 1px solid #ccc; text-decoration: none; color: black; border-radius: 5px;">Back to Main Menu</a>';
?>