<?php
include 'connection.php';

$sql = "SELECT LOCALTIME()";
$result = $conn->query($sql);

echo "<h3>Function: LOCALTIME (Returns Current Local Time)</h3>";
    echo "  <table border='1'>
                <tr>
                    <th>Result Local Time</th>
                </tr>";

while($row = $result->fetch_assoc()) {
    echo "  <tr>
                <td>{$row['LOCALTIME()']}</td>
            </tr>";
}


echo "</table>";
echo "<br><br>";
echo '<a href="index.php" style="padding: 10px; background-color: #f0f0f0; border: 1px solid #ccc; text-decoration: none; color: black; border-radius: 5px;">Back to Main Menu</a>';
?>