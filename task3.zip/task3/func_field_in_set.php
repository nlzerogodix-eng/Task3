<?php
include 'connection.php';

$sql = "SELECT id, name, FIND_IN_SET(id, '1,2,3') AS position 
        FROM `usertbl` 
        WHERE FIND_IN_SET(id, '1,2,3') > 0";

$result = $conn->query($sql);

if (!$result) {
    die("SQL Error: " . $conn->error); 
}

echo "<h3> Output for FIND_IN_SET </h3>";


while($row = $result->fetch_assoc()){
    echo "ID: " . $row['id'] . " is at position: " . $row['position'] . "<br>";
}
echo "<br><br>";
echo '<a href="index.php" style="padding: 10px; background-color: #f0f0f0; border: 1px solid #ccc; text-decoration: none; color: black; border-radius: 5px;">Back to Main Menu</a>';
?>