<?php
include 'connection.php';

$sql = "SELECT id, name, gender FROM `usertbl` ORDER BY FIELD(gender, 'Male', 'Female') ASC;";

$result = $conn->query($sql);

echo "<h3> Sorted by Custom Gender Priority </h3>";

while($row = $result->fetch_assoc()){
    echo "ID: " . $row['id'] . " | Name: " . $row['name'] . " (" . $row['gender'] . ")<br>";
}
echo "<br><br>";
echo '<a href="index.php" style="padding: 10px; background-color: #f0f0f0; border: 1px solid #ccc; text-decoration: none; color: black; border-radius: 5px;">Back to Main Menu</a>';
?>