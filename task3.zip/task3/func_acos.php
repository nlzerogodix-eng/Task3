<?php
include 'connection.php';
$sql = "SELECT ACOS(0.25)";
$result = $conn->query($sql);


echo "<h3>Output for ACOS() Function</h3>";

while($row = $result->fetch_assoc()) {
    echo "Arc Cosine Value: ". $row['ACOS(0.25)'] . "<br>";
}

echo "<br><br>";
echo '<a href="index.php" style="padding: 10px; background-color: #f0f0f0; border: 1px solid #ccc; text-decoration: none; color: black; border-radius: 5px;">Back to Main Menu</a>';
?>