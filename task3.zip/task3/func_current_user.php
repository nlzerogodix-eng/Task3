<?php
include 'connection.php';

$sql = "SELECT CURRENT_USER()";
$result = $conn->query($sql);


echo "<h3>Output for CURRENT_USER() Function</h3>";
while($row = $result->fetch_assoc()) {
    echo "CURRENT_USER Result = ". $row['CURRENT_USER()'] . "<br>";
}

echo "<br><br>";
echo '<a href="index.php" style="padding: 10px; background-color: #f0f0f0; border: 1px solid #ccc; text-decoration: none; color: black; border-radius: 5px;">Back to Main Menu</a>';
?>