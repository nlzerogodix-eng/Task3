<?php
include 'connection.php';

$sql = "SELECT HOUR('2026-01-05 09:15:00')";
$result = $conn->query($sql);

echo "<h3>Function: HOUR (Returns Hour from Time)</h3>";
    echo "  <table border='1'>
                <tr>
                    <th>Result Hour</th>
                </tr>";

while($row = $result->fetch_assoc()) {
    echo "  <tr>
                <td>{$row['HOUR(\'2026-01-05 09:15:00\')']}</td>
            </tr>";
}


echo "</table>";
echo "<br><br>";
echo '<a href="index.php" style="padding: 10px; background-color: #f0f0f0; border: 1px solid #ccc; text-decoration: none; color: black; border-radius: 5px;">Back to Main Menu</a>';
?>