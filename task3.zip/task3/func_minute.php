<?php
include 'connection.php';

$sql = "SELECT MINUTE('2025-06-20 09:34:00')";
$result = $conn->query($sql);

echo "<h3>Function: MINUTE (Returns Minute Value from Time)</h3>";
    echo "  <table border='1'>
                <tr>
                    <th>Result Minute</th>
                </tr>";

while($row = $result->fetch_assoc()) {
    echo "  <tr>
                <td>{$row['MINUTE(\'2025-06-20 09:34:00\')']}</td>
            </tr>";
}


echo "</table>";
echo "<br><br>";
echo '<a href="index.php" style="padding: 10px; background-color: #f0f0f0; border: 1px solid #ccc; text-decoration: none; color: black; border-radius: 5px;">Back to Main Menu</a>';
?>