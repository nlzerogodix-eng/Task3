<?php
include 'connection.php';


$sql = "SELECT UCASE('SQL Tutorial is FUN!') AS TrimmedString"; 
$result = $conn->query($sql);

echo "<h3>Output for UCASE() Function</h3>";

if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
     
        echo $row['TrimmedString'] . "<br>";
    }
} else {
    echo "0 results or error: " . $conn->error;
}

echo "<br><br>";
echo '<a href="index.php" style="padding: 10px; background-color: #f0f0f0; border: 1px solid #ccc; text-decoration: none; color: black; border-radius: 5px;">Back to Main Menu</a>';
?>