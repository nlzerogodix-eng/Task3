<?php
include 'connection.php';

$sql = "SELECT TIME('2022-08-15 19:30:10.000001')";
$result = $conn->query($sql);

echo "<h3>Function: TIME (Extracts Time from a Date-Time Value)</h3>";
    echo "  <table border='1'>
                <tr>
                    <th>Result Time</th>
                </tr>";

while($row = $result->fetch_assoc()) {
    echo "  <tr>
                <td>{$row['TIME(\'2022-08-15 19:30:10.000001\')']}</td>
            </tr>";
}


echo "</table>";
echo "<br><br>";
echo '<a href="index.php" style="padding: 10px; background-color: #f0f0f0; border: 1px solid #ccc; text-decoration: none; color: black; border-radius: 5px;">Back to Main Menu</a>';
?>