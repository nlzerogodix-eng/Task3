<?php
include 'connection.php';

$sql = "SELECT DATEDIFF('2025-01-15', '2026-01-05')";
$result = $conn->query($sql);

echo "<h3>Function: DATEDIFF (Returns Difference in Days)</h3>";
    echo "  <table border='1'>
                <tr>
                    <th>Result Days</th>
                </tr>";

while($row = $result->fetch_assoc()) {
    echo "  <tr>
                <td>{$row['DATEDIFF(\'2025-01-15\', \'2026-01-05\')']}</td>
            </tr>";
}


echo "</table>";
echo "<br><br>";
echo '<a href="index.php" style="padding: 10px; background-color: #f0f0f0; border: 1px solid #ccc; text-decoration: none; color: black; border-radius: 5px;">Back to Main Menu</a>';
?>