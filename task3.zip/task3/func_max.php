<?php
include 'connection.php';
$sql = "SELECT MAX(points) AS LargestPoint FROM user_points";
$result = $conn->query($sql);


echo "<h3>Output for MAX() Function</h3>";
while($row = $result->fetch_assoc()) {
    echo "Largest Point: ". $row['LargestPoint'] . "<br>";
}

echo "<br><br>";
echo '<a href="index.php" style="padding: 10px; background-color: #f0f0f0; border: 1px solid #ccc; text-decoration: none; color: black; border-radius: 5px;">Back to Main Menu</a>';
?>