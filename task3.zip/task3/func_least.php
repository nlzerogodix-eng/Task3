<?php
include 'connection.php';
$sql = "SELECT LEAST(3, 12, 34, 8, 25)";
$result = $conn->query($sql);


echo "<h3>Output for LEAST() Function</h3>";
while($row = $result->fetch_assoc()) {
    echo "Least Value: ". $row['LEAST(3, 12, 34, 8, 25)'] . "<br>";
}

echo "<br><br>";
echo '<a href="index.php" style="padding: 10px; background-color: #f0f0f0; border: 1px solid #ccc; text-decoration: none; color: black; border-radius: 5px;">Back to Main Menu</a>';
?>