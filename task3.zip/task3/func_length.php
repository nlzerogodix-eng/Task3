<?php
include 'connection.php';

$sql = "SELECT LENGTH('SQL Tutorial') AS LengthOfString"; 
$result = $conn->query($sql);

echo "<h3>Output for LENGTH() Function</h3>";

if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {

        echo "The length is: " . $row['LengthOfString'] . "<br>";
    }
} else {
    echo "0 results or query error: " . $conn->error;
}

echo "<br><br>";
echo '<a href="index.php" style="padding: 10px; background-color: #f0f0f0; border: 1px solid #ccc; text-decoration: none; color: black; border-radius: 5px;">Back to Main Menu</a>';
?>