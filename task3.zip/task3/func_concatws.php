<?php
include 'connection.php';

$sql = "SELECT id, CONCAT_WS(' | ', name, email, gender, created_at) AS user_summary FROM `usertbl`;";

$result = $conn->query($sql);

echo "<h3> OUTPUT for CONCAT_WS() Function </h3>";

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()){
        echo $row['user_summary'] . "<br>";
    }
} else {
    echo "0 results found.";
}

$conn->close();
echo "<br><br>";
echo '<a href="index.php" style="padding: 10px; background-color: #f0f0f0; border: 1px solid #ccc; text-decoration: none; color: black; border-radius: 5px;">Back to Main Menu</a>';
?>