<?php
include 'connection.php';

$sql = "SELECT SEC_TO_TIME(500)";
$result = $conn->query($sql);

echo "<h3>Function: SEC_TO_TIME (Converts Seconds to Time)</h3>";
    echo "  <table border='1'>
                <tr>
                    <th>Result Time</th>
                </tr>";

while($row = $result->fetch_assoc()) {
    echo "  <tr>
                <td>{$row['SEC_TO_TIME(500)']}</td>
            </tr>";
}


echo "</table>";
echo "<br><br>";
echo '<a href="index.php" style="padding: 10px; background-color: #f0f0f0; border: 1px solid #ccc; text-decoration: none; color: black; border-radius: 5px;">Back to Main Menu</a>';
?>