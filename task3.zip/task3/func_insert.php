<?php
include 'connection.php';

$sql = "INSERT INTO `usertbl` (`name`, `password`, `email`, `gender`) 
        VALUES ('John Doe', '12345', 'john@example.com', 'Male');";

echo "<h3> Simple INSERT Method </h3>";


if ($conn->query($sql) === TRUE) {
    $last_id = $conn->insert_id; 
    echo "<p style='color: green;'>New record created successfully! New ID is: " . $last_id . "</p>";
} else {
    echo "Error: " . $conn->error;
}

echo "<br><br>";
echo '<a href="index.php" style="padding: 10px; background-color: #f0f0f0; border: 1px solid #ccc; text-decoration: none; color: black; border-radius: 5px;">Back to Main Menu</a>';
?>